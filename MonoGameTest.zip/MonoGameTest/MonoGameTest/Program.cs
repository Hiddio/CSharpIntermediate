﻿
using var game = new MonoGameTest.Game1();
game.Run();
